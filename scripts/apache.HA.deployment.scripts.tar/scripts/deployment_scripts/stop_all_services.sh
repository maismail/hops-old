#!/bin/bash
# Author: Salman Niazi 2014
# This script broadcasts all files required for running a HOP instance.
# A password-less sign-on should be setup prior to calling this script


source stop_NNs.sh
source stop_DNs.sh
source stop_yarn.sh
exit 0



