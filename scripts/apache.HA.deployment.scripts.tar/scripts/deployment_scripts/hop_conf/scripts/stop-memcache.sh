#!/bin/bash

kill $(ps ax  | awk '/memcached/ {print $1}') 
