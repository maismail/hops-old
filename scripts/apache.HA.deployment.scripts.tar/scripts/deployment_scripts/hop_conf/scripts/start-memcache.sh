#!/bin/bash

memcached -uroot -m 1024 -d 127.0.0.1 -p 11211
